# pyselect/src/pyselect/__init__.py
"""The pyselect package."""
__version__ = "0.1.0"

from pyselect.estimators import RFFNetClassifier, RFFNetRegressor
